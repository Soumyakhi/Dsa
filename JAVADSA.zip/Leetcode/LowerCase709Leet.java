public class LowerCase709Leet {
    public String toLowerCase(String s) {
        return s.toLowerCase();
    }
    public static void main(String[] args) {
        System.out.println((new LowerCase709Leet()).toLowerCase("Hello"));
    }
}